XSA - SAP HANA XS Advanced Model
================================

SAP HANA Academy - XS Advanced Model code samples for playlist https://www.youtube.com/playlist?list=PLkzo92owKnVwL3AWaWVbFVrfErKkMY02a
